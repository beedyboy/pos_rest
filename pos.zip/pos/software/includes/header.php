<?php include('loginChecker.php'); ?>
<!DOCTYPE html>
<html>
	<head>
		<title>School Management System</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link href="../css/font-awesome.css" rel="stylesheet" media="screen">
		<link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">
		<link href="../css/jquery.timepicker.css" rel="stylesheet" media="screen">
		<link href="../css/jquery-ui.css" rel="stylesheet" media="screen">
		<link href="../css/style.css" rel="stylesheet" media="screen">
		<link href="../css/custom.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="../css/font-awesome.min.css">
		<script type="text/javascript">
		//	window.site_url = 'http://localhost:81/attmonsys/';
		</script>
	</head>
	<body>
	<div id="mainContext">