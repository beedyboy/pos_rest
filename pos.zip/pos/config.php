
<?php 
//require "software/classes/session.php";
require "login.php";
 
	//$GetSession = new Session;
define('WEB_URL', 'http://localhost:90/ams/');
define('ROOT_PATH', 'C:\wamp\www\ams/');
?>