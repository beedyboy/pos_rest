  
  
  var num1: number = 5;
  console.log(num1);