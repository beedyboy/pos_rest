 

<?php 
//$header = "header.php";
//$newMember = "newMember.php";		
//$footer = "footer.php";		
 //$GetSession = new Session;
 
 echo "hey";
?>