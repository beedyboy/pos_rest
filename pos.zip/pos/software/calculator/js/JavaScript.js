function Calc(Val)
                      {
		alert(Val);
	                   }