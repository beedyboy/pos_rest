 <?php include('header.php');?>
<body>
	
<div class="container ben">
	<div class="row">
	<form class= " col-md-7 sydney">
		  <input type="checkbox"  class="col-sm-3 dorcas" name="menu[]" >
		  <label class="col-md-7 sam">Fried Rice</label>
		  <input type="number" name="quantity" value="1"   maxlength="2" style=" width:30px;">
		  
		   
     </form>
	
	
	
<!--	<form class= " col-md-7 sydney">
		   
		   <input type="checkbox"  class="col-md-3 dorcas" name="menu[]" >
		  <label class="col-md-7 sam">Konkonte and light soup</label>
		  <input type="number" name="quantity" value="1"  maxlength="2" style=" width:30px;">
     </form>
	
	<form class= " col-sm-7 sydney">
		  <input type="checkbox"  class="col-md-3 dorcas" name="menu[]" >
		  <label class="col-md-7 sam">Akpligeeee</label>
		  <input type="number" name="quantity" value="1"   maxlength="2" style=" width:30px;">
		  
		     </form>
	
	<form class= " col-sm-7 sydney">
		    
		   <input type="checkbox"  class="col-sm-3 dorcas" name="menu[]" >
		  <label class="col-md-7 sam">Yam with palava sauce</label>
		  <input type="number" name="quantity" value="1"  maxlength="2" style=" width:30px;">
     </form>
	
	</div>-->
</div>
	 
	 
 
 
	  
	
	
	<?php include('footer3.php');?>
</body>
</html>