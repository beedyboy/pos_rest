<form id="saveFoodSubCat">
			  
				
<center><h4><i class="icon-plus-sign icon-large"></i> Add Sub Category</h4></center>
<hr />
			<input type="hidden" name="action" value="saveFoodSubCat" />
			
				 <label>Main Category</label>
					<select name="main" class="custom-select form-control  mr-sm-2 mb-2 mb-sm-0" required>
<option value="">--Select One--</option>
<option value="C">Continental</option>
<option value="L">Local Dishes</option> 
<option value="D">Drinks</option> 
<option value="S">Soup</option> 
<option value="F">Fish - Chicken</option> 
<option value="SM">Special Meal</option> 
</select>
					 	<br />
				<label>Sub Category</label>
					<input type="text"  class="form-control" name="sub" Required/>
                       <br />
					   
			  
				
				<div id="add-bottom" style=" margin:10px 0 0;" class="col-md-offset-1 col-md-11 alert hide"></div>
				 <div style="float:right; margin-right:50px;">
				 
				<button class="btn btn-success btn-block btn-large pull-right" title="Click to Save" style="width:267px;">
					<i class="icon icon-save icon-large"></i> Save</button>
 </div>
  
		</form>


 
<script src="js/beedy.js" type="text/javascript"></script>  