<?php
$yes=" my name is bolade akinniyi";
$db="sms";
$dbusername="root";
$dbpassword="pass";
 
 $dsn  = "'mysql:host='.$yes.';dbname='.$db, $dbusername, $dbpassword); \n" ;
 echo $dsn;
?>