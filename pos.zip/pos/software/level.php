<?php 
	require_once('auth.php');
 echo $GetSession->position;
?>   
 